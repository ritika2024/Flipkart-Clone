export var imageslider= [
    {
        img:"https://rukminim2.flixcart.com/fk-p-flap/1688/280/image/64052861692b9bff.jpg?q=50",
        link: "https://www.flipkart.com/big-savings-days-store?param=985767&otracker=hp_bannerads_1_2.bannerAdCard.BANNERADS_s_N3VQOXU0RYZR"
    },
    {
        img:"https://rukminim2.flixcart.com/fk-p-flap/1688/280/image/73d1084d7c994a80.jpg?q=50",
        link: "https://www.flipkart.com/mobiles/pr?sid=tyy%2C4io&p%5B%5D=facets.price_range.from%3D20000&p%5B%5D=facets.price_range.to%3DMax&param=3890&otracker=hp_bannerads_2_2.bannerAdCard.BANNERADS_r_5OXU5YSBDK4H"
    },
        {
        img:"https://rukminim2.flixcart.com/fk-p-flap/1688/280/image/8a664fff4b84a601.png?q=50",
        link: "https://www.flipkart.com/6bo/b5g/~cs-j06oa56i18/pr?sid=6bo%2Cb5g&collection-tab-name=Intel+Gaming+Laptops&otracker=hp_bannerads_3_2.bannerAdCard.BANNERADS_Intel_G30TI7EFFF0B"
    },
    {
        img:"https://rukminim2.flixcart.com/fk-p-flap/1688/280/image/23b4eadb6a3828f6.png?q=50",
        link: "https://www.flipkart.com/6bo/b5g/~cs-yr1vxer28o/pr?sid=6bo%2Cb5g&collection-tab-name=Intel+Laptops&otracker=hp_bannerads_4_2.bannerAdCard.BANNERADS_Intel_BCOZ10G67GSX"
    },
    {
        img:"https://rukminim2.flixcart.com/fk-p-flap/3376/560/image/8db16165a9f1ff9a.png?q=50",
        link: "https://www.flipkart.com/avita-liber-core-i7-10th-gen-16-gb-1-tb-ssd-windows-10-home-ns14a8inr671-pag-thin-light-laptop/p/itmbe8a49652ca6f?pid=COMGQKQ7GGNFR8N4&otracker=hp_bannerads_5_2.bannerAdCard.BANNERADS_DT_5XUOO21AUBQU"
    },
    {
        img:"https://rukminim2.flixcart.com/fk-p-flap/3376/560/image/b086f75214cff988.jpg?q=50",
        link: "https://www.flipkart.com/travel/flights?param=Travel_FKHP_DT-HPW_BSD-Dom1299&otracker=hp_bannerads_6_2.bannerAdCard.BANNERADS_d_8NWUCBZ98VWK"
    },
    {
        img:"https://rukminim2.flixcart.com/fk-p-flap/3376/560/image/8b7586d209ff39bd.jpg?q=50",
        link: "https://www.flipkart.com/ckf/czl/~cs-1wnqrna2xz/pr?sid=ckf%2Cczl&collection-tab-name=Hero+Deals&sort=popularity&p%5B%5D=facets.availability%255B%255D%3DExclude%2BOut%2Bof%2BStock&otracker=hp_bannerads_7_2.bannerAdCard.BANNERADS_a_8UJ2DAKL9JPF"
    }
]